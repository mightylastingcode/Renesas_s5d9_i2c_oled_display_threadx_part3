/* generated configuration header file - do not edit */
#ifndef BSP_BOARD_CFG_H_
#define BSP_BOARD_CFG_H_
#include "../../../synergy/board/s5d9_iot_enabler/bsp.h"
#endif /* BSP_BOARD_CFG_H_ */
